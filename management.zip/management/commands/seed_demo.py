from decimal import Decimal

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from shop.models import Category, CustomerProfile, DeliveryProfile, Order, OrderItem, Product, Store


class Command(BaseCommand):
    help = "Seed AfriShop demo users, stores, products, and orders."

    def handle(self, *args, **options):
        admin = self._user("admin", "Admin@123", "AfriShop", "Admin", "admin@afrishop.local", staff=True, superuser=True)
        customer = self._user("customer", "Customer@123", "Daniel", "Okafor", "customer@afrishop.local")
        seller = self._user("seller", "Seller@123", "Daniel", "Seller", "seller@afrishop.local", staff=True)
        mama_seller = self._user("mama", "Seller@123", "Amara", "Seller", "mama@afrishop.local", staff=True)
        delivery = self._user("delivery", "Delivery@123", "Aman", "Singh", "delivery@afrishop.local")

        CustomerProfile.objects.update_or_create(
            user=customer,
            defaults={
                "phone": "+91 98765 43210",
                "address": "Sarabha Nagar, Ludhiana, Punjab",
            },
        )
        DeliveryProfile.objects.update_or_create(
            user=delivery,
            defaults={
                "phone": "+91 98765 43230",
                "city": "Ludhiana",
                "vehicle_type": "Bike",
                "vehicle_number": "PB10 AB 1234",
                "status": DeliveryProfile.AVAILABLE,
            },
        )

        categories = {
            "Nigerian": ("nigerian", "shopping-bag", "#147A32"),
            "Ghanaian": ("ghanaian", "package", "#2FAA50"),
            "Kenyan": ("kenyan", "cup-soda", "#111827"),
            "Snacks": ("snacks", "cookie", "#F5A623"),
            "More": ("more", "layout-grid", "#667085"),
        }
        category_objs = {}
        for name, (slug, icon, color) in categories.items():
            category_objs[name], _ = Category.objects.update_or_create(
                slug=slug,
                defaults={"name": name, "icon": icon, "color": color},
            )

        naija, _ = Store.objects.update_or_create(
            slug="naija-superstore",
            defaults={
                "owner": seller,
                "name": "Naija Superstore",
                "tagline": "African Grocery Store",
                "description": "We sell authentic African groceries and products.",
                "phone": "+91 98765 43220",
                "email": "naijasuperstore@gmail.com",
                "city": "Ludhiana",
                "address": "Sarabha Nagar Market, Ludhiana, Punjab",
                "latitude": Decimal("30.900965"),
                "longitude": Decimal("75.808920"),
                "opening_hours": "9:00 AM - 10:00 PM",
                "rating": Decimal("4.6"),
                "delivery_minutes_min": 30,
                "delivery_minutes_max": 40,
                "delivery_fee": Decimal("30.00"),
                "cover_image": "shop/img/store-cover.jpg",
                "logo_image": "shop/img/logo-customer.jpg",
                "is_open": True,
            },
        )
        mama, _ = Store.objects.update_or_create(
            slug="mama-africa-kitchen",
            defaults={
                "owner": mama_seller,
                "name": "Mama Africa Kitchen",
                "tagline": "Kitchen",
                "description": "Fresh ingredients, spices, and snacks for everyday cooking.",
                "phone": "+91 98765 43221",
                "email": "mama@afrishop.local",
                "city": "Ludhiana",
                "address": "Model Town, Ludhiana, Punjab",
                "latitude": Decimal("30.878620"),
                "longitude": Decimal("75.842960"),
                "opening_hours": "10:00 AM - 9:00 PM",
                "rating": Decimal("4.7"),
                "delivery_minutes_min": 25,
                "delivery_minutes_max": 35,
                "delivery_fee": Decimal("35.00"),
                "cover_image": "shop/img/store-profile-cover.jpg",
                "logo_image": "shop/img/logo-customer.jpg",
                "is_open": True,
            },
        )

        product_data = [
            (naija, category_objs["Nigerian"], "Indomie Noodles (Chicken)", "indomie-noodles-chicken", "Classic Indomie chicken flavour. Quick, tasty and loved across Africa.", "120.00", "shop/img/product-indomie.jpg", 20, True),
            (naija, category_objs["Nigerian"], "Semolina (1kg)", "semolina-1kg", "Made from premium wheat for smooth swallows.", "180.00", "shop/img/product-semolina.jpg", 14, False),
            (naija, category_objs["Ghanaian"], "Palm Oil (1L)", "palm-oil-1l", "Authentic African palm oil for soups, stews and sauces.", "350.00", "shop/img/product-palmoil.jpg", 18, True),
            (naija, category_objs["Nigerian"], "Maggi Cubes (Pack)", "maggi-cubes-pack", "Chicken flavour seasoning cubes.", "60.00", "shop/img/product-maggi.jpg", 30, True),
            (mama, category_objs["Snacks"], "Chin Chin Snack", "chin-chin-snack", "Crunchy sweet snack for tea time.", "90.00", "shop/img/product-semolina.jpg", 24, False),
            (mama, category_objs["Kenyan"], "Jollof Spice Mix", "jollof-spice-mix", "Balanced spices for smoky party jollof.", "140.00", "shop/img/product-maggi.jpg", 16, True),
        ]
        products = {}
        for store, category, name, slug, description, price, image, stock, featured in product_data:
            products[slug], _ = Product.objects.update_or_create(
                slug=slug,
                defaults={
                    "store": store,
                    "category": category,
                    "name": name,
                    "description": description,
                    "price": Decimal(price),
                    "image": image,
                    "stock": stock,
                    "featured": featured,
                    "active": True,
                },
            )

        if not Order.objects.filter(customer=customer).exists():
            self._order(
                customer,
                naija,
                Order.OUT_FOR_DELIVERY,
                [(products["indomie-noodles-chicken"], 2), (products["maggi-cubes-pack"], 1), (products["palm-oil-1l"], 1)],
            )
            self._order(customer, mama, Order.PREPARING, [(products["jollof-spice-mix"], 2), (products["chin-chin-snack"], 3)])
            self._order(customer, naija, Order.DELIVERED, [(products["semolina-1kg"], 1), (products["maggi-cubes-pack"], 2)])

        self.stdout.write(self.style.SUCCESS("AfriShop demo data is ready."))
        self.stdout.write("Admin:    admin / Admin@123")
        self.stdout.write("Customer: customer / Customer@123")
        self.stdout.write("Seller:   seller / Seller@123")
        self.stdout.write("Delivery: delivery / Delivery@123")

    def _user(self, username, password, first_name, last_name, email, staff=False, superuser=False):
        user, _ = User.objects.update_or_create(
            username=username,
            defaults={
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "is_staff": staff or superuser,
                "is_superuser": superuser,
                "is_active": True,
            },
        )
        user.set_password(password)
        user.save()
        return user

    def _order(self, customer, store, status, items):
        item_total = sum(product.price * qty for product, qty in items)
        order = Order.objects.create(
            customer=customer,
            store=store,
            status=status,
            delivery_address="Sarabha Nagar, Ludhiana, Punjab",
            payment_method=Order.CASH,
            item_total=item_total,
            delivery_fee=store.delivery_fee,
        )
        for product, quantity in items:
            OrderItem.objects.create(
                order=order,
                product=product,
                quantity=quantity,
                unit_price=product.price,
            )
        return order
